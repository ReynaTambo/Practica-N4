package com.emergentes.dao;

import com.emergentes.modelo.Avisoss;
import java.util.List;

public interface avisoDAO {

    public void insert(Avisoss aviso) throws Exception;
    public void updata(Avisoss aviso) throws Exception;
    public void delete(int id) throws Exception;
    public  void  getById (int id) throws Exception;
    public List<Avisoss> getAll () throws Exception;

}
