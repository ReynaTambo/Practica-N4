package com.emergentes.dao;

import com.emergentes.modelo.Avisoss;
import com.emergentes.utiles.ConexionDB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AvisoDaoImpl extends ConexionDB implements avisoDAO {

    @Override
    public void insert(Avisoss aviso) throws Exception {
        try {
            this.conectar();//ojito con avisos
            String sql = "INSERT into avisos (fecha,titulo,contenido) values (?,?,?)";
            PreparedStatement ps = this.conn.prepareStatement(sql);

            ps.setString(1, aviso.getFecha());
            ps.setString(2, aviso.getTitulo());
            ps.setString(3, aviso.getContenido());
            // ejecutamos

            ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public void updata(Avisoss aviso) throws Exception {
        try {
            this.conectar();//ojito con avisos
            String sql = "UPDATE avisos set fecha=?, titulo=?, contenido=? where id =?";
            PreparedStatement ps = this.conn.prepareStatement(sql);

            ps.setString(1, aviso.getFecha());
            ps.setString(2, aviso.getTitulo());
            ps.setString(3, aviso.getContenido());
            ps.setInt(4, aviso.getId());

            // ejecutamos
            ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public void delete(int id) throws Exception {
        try {
            this.conectar();//ojito con avisos
            String sql = "DELETE from avisos where id =?";
            PreparedStatement ps = this.conn.prepareStatement(sql);

            ps.setInt(1, id);

            // ejecutamos
            ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }

    }

    @Override
    public void getById(int id) throws Exception {

        // devuele aviso 
        Avisoss sal = new Avisoss(); // .modelo
        try {
            this.conectar();

            String sql = "select * from avisos where id = ?";
            PreparedStatement ps = this.conn.prepareStatement(sql);
            ps.setInt(1, id);
            // ejecutamos la consulta obteniendo el registro
            ResultSet rs = ps.executeQuery();

            // veremos si tiene registros
            if (rs.next()) {
                sal.setId(rs.getInt("id"));
                sal.setFecha(rs.getString("fecha"));
                sal.setTitulo(rs.getString("titulo"));
                sal.setContenido(rs.getString("contenido"));
            }

        } catch (Exception e) {
            throw e;

        } finally {
            this.desconectar();
        }
    }

    @Override
    public List<Avisoss> getAll() throws Exception {
        List<Avisoss> lista = null;
        try {
            // conectamos a la base de datos 
            this.conectar();
            String sql = "select * from avisos";
            PreparedStatement ps = this.conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            // es un conjunto de registros 
            lista = new ArrayList<Avisoss>();

            while (rs.next()) {
                Avisoss sal = new Avisoss();
                sal.setId(rs.getInt("id"));
                sal.setFecha(rs.getString("fecha"));
                sal.setTitulo(rs.getString("titulo"));
                sal.setContenido(rs.getString("contenido"));
                
                // adicionar a la colexioin 
                lista.add(sal);
            }

        } catch (Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
        return lista;
    }

}
